/*----------------------------------------------------------------------------
 *      main Template for pc C/C++ Project
 *----------------------------------------------------------------------------
 *      Name:    main.c
 *      Purpose: Generic main program body including main() function
 *      Rev.:    1.0.0
 *----------------------------------------------------------------------------*/
#include "stdint.h"

/* main function */
int main(void)
{


	//TODO: add system initialize code here;

	/* Infinite loop */
	while (1) {

		//TODO: Add application code here

	}

}

