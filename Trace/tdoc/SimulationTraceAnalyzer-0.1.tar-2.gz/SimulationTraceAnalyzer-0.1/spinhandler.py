#!/usr/bin/python

'''
Created on Feb 4, 2012

@author: Ayesha Yasmeen
'''

import time
import commands

def executePan(pmlFileName, propertyName):
    '''
        Execute the pan process to determine whether a property is satisfied by a given model
        
        Arguments:
        arg1: The name of the Promela encoding of the model, typically ends with a .pml extension
        arg2: The name of the property that is going to be verified. The properties are listed sequentially at the end of the pml file, 
              where each of them are assigned a name. That exact name needs to be mentioned here to get that property verified. 
    '''
    (status,output) = commands.getstatusoutput("./pan -m100000 -N " + propertyName + " > " + pmlFileName.replace("pml","out" + propertyName))
    print "pan analyzed " + propertyName + " and said " + output
    return "pan analyzed " + propertyName + " and said " + output

def processPMLFile(pmlfilename):
    """
     This function processes a Promela input file vis model checker SPIN. Maximum utilization of storage space and memory
     is attempted. It also records the time required to process the model.
     
     Arguments:
     arg1: The name of the .pml filename containing the model.
    """

    traceVerifierConsoleOutput = []
    
    start_time = time.time()

    print "Starting spin verifier on " + pmlfilename + " ..."
    traceVerifierConsoleOutput.append("Starting spin verifier on " + pmlfilename + " ...")
    (status,output) = commands.getstatusoutput("spin -a " + pmlfilename)
    print "Spin took " + str( time.time() - start_time ) + " seconds."
    print "Spin said: " + output
    traceVerifierConsoleOutput.append("Spin took " + str( time.time() - start_time ) + " seconds.")
    traceVerifierConsoleOutput.append("Spin said: " + output)

    print "Starting to prepare pan..."
    traceVerifierConsoleOutput.append("Starting to prepare pan...")
    
    start_time = time.time()
    (status,output) = commands.getstatusoutput("gcc -O2 -DVECTORSZ=4096 -DMEMLIM=512 -DSAFETY -DBITSTATE -o pan pan.c")
    print "gcc took " + str( time.time() - start_time ) + " seconds."
    traceVerifierConsoleOutput.append("gcc took " + str( time.time() - start_time ) + " seconds.")

    print "Creating output file ..."
    traceVerifierConsoleOutput.append("Creating output file ...")
    
    ltlFormulae = [ endingLine.split(" ")[1] for endingLine in open('/Users/yasmeen/Research/TraceAnalysis/ending.pml',"r").read().split("\n") 
                    if endingLine.startswith("ltl ")]

    for ltlFormula in ltlFormulae:
        traceVerifierConsoleOutput.append(executePan(pmlfilename, ltlFormula))
    
    open(pmlfilename[:-3] + "console","w").write("\n".join(traceVerifierConsoleOutput))
    
    print "Analysis complete!"




