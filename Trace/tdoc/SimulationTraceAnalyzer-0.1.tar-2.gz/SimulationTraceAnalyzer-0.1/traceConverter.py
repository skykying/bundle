'''
Created on Feb 12, 2012

@author: Ayesha Yasmeen
'''

import spinhandler
import os.path
import commands
import itertools
import re
import getopt
import sys

def myFindIndex2(searchList = [], searchStr = "", backWardSearch = False):
    notFound = True
    index = 0
    firstLocationInTrace = -1
    while notFound and index < len(searchList):
        if backWardSearch == True :
            firstLocationInTrace = searchList[index].rfind(searchStr)
        else:
            
            firstLocationInTrace = searchList[index].find(searchStr)
        if firstLocationInTrace > -1:
            notFound = False
        else:
            index = index + 1


def myFindIndex(searchList = [], searchStr = "", backWardSearch = False):
    notFound = True
    index = 0
    if not (backWardSearch):
        while notFound and index < len(searchList):
            
            if not ( searchList[index].find(searchStr) > -1):
                index = index + 1
            else:
                temp = [ st.find(searchStr) for st in searchList[index].split("\t") if st.find(searchStr) > -1]
                #print temp
                #print searchList[index]
                if len(temp) > 0 :
                    if  searchList[temp[0]-2] == "Set resource":                    
                        notFound = False
                    else:
                        index = index + 1
                else:
                    index = index + 1
    else:
        index = len(searchList) - 1 
        while notFound and index > 0 :
            if not ( searchList[index].rfind(searchStr) > -1):
                index = index - 1
            else:
                notFound = False       
    return index

def findnumlinesintracefile(tracefilename):
    outut = commands.getoutput('wc -l %s' % re.sub(' ','\ ', tracefilename))
    return outut

def handleTraceWithSpin(traceFileName):
    '''
    Convert a csv simulation trace into Promela
    '''
    #traceFileName = r"/Users/yasmeen/svnNASA/NASA 2009/WMC/WMC-OutputAndResults/50SC33FA4STR/CDactiontracefile.txt"
    
    traceContent = open( traceFileName,"r").read().split("\n")
    print "Trace file length " + str(len(traceContent))
    
    desiredVariables = [ "CDAAC_altitude", "waypointtocompare", "altitude_clearance"]
        
    altitudeOutput = []
    
    promelaCode = open("/Users/yasmeen/Research/TraceAnalysis/preamble.pml","r").read().split("\n")
    
    currTime = ""
    
    firstPosInTrace, lastPosInTrace = ( 0, 0)
    if os.path.exists(traceFileName):
        firstPosInTrace, lastPosInTrace = map(int,open(os.path.join(os.path.split(traceFileName)[0],'traceportion.txt')).readline().split(':'))
    else:
        firstPosInTrace = 0
        lastPosInTrace = findnumlinesintracefile(traceFileName) - 1

    
    for traceLine in traceContent[firstPosInTrace:lastPosInTrace]:
        
        traceElems = [traceElem.strip() for traceElem in traceLine.split("\t")]
    
        if traceElems[1].split(":")[1] == "dialVSSelector" :
            promelaCode.append('manualAction = true ;')
        
        currPosInTrace = 4
    
        if not (currTime == traceElems[0] ):
            #promelaCode.append("MockChan!true ;")
            #promelaCode.append("MockChan?true ;")
            promelaCode.append("/* " + traceElems[0] + " */")
            currTime = traceElems[0]
        
    
        while currPosInTrace < len(traceElems):
            if traceElems[currPosInTrace].startswith("NUT") :
                currPosInTrace = currPosInTrace + 5
            elif traceElems[currPosInTrace] == "Set resource" and ( traceElems[currPosInTrace+1] in desiredVariables) :
                if traceElems[currPosInTrace + 1 ] == "CDAAC_altitude" :
                    promelaCode.append("\tprevAlt = currAlt ;")
                    #promelaCode.append("\tcurrAlt = " + str(int((float(traceElems[currPosInTrace+3]) / 30850 ) * 256)) + " ;")
                    promelaCode.append("\tcurrAlt = " + str(int((float(traceElems[currPosInTrace+3])  ) )) + " ;")
                    altitudeOutput.append( traceElems[currPosInTrace+3])
                
                elif traceElems[currPosInTrace + 1 ] == "CDAAC_latitude" :
                    promelaCode.append("\tprevLat = currLat ;")
                    promelaCode.append("\tcurrLat = " + str(int((float(traceElems[currPosInTrace+3]) * 100) - 3393)) + " ;")
                
                elif traceElems[currPosInTrace + 1 ] == "CDAAC_longitude" :
                    promelaCode.append("\tprevLon = currLon ;")
                    promelaCode.append("\tcurrLon = " + str(int((float(traceElems[currPosInTrace+3]) * 100) + 11837)) + " ;")
    
                elif traceElems[currPosInTrace + 1 ] == "CDAAC_groundspeed" :
                    promelaCode.append("\tprevSpd = currSpd ;")
                    promelaCode.append("\tcurrSpd = " + str(int((float(traceElems[currPosInTrace+3]) ) - 148)) + " ;")
                
                elif traceElems[currPosInTrace + 1 ] == "altitude_clearance" :
                    promelaCode.append("\tclearedAltitude = " + str(int((float(traceElems[currPosInTrace+3]) ) )) + " ;")
    
                elif traceElems[currPosInTrace + 1 ] == "waypointtocompare" :
                    promelaCode.append("\tprevWayPoint.wpName = currWayPoint.wpName ;")
                    promelaCode.append("\tprevWayPoint.wpAlt = currWayPoint.wpAlt ;")
                    promelaCode.append("\tprevWayPoint.wpLat = currWayPoint.wpLat ;")
                    promelaCode.append("\tprevWayPoint.wpLon = currWayPoint.wpLon ;")
                    promelaCode.append("\tprevWayPoint.wpSpd = currWayPoint.wpSpd ;")
                    
                    if traceElems[currPosInTrace + 3].startswith("LAT"):                    
                        promelaCode.append("\tcurrWayPoint.wpName = START ;\n\tcurrWayPoint.wpLat = 67 ;\n\tcurrWayPoint.wpLon = 235 ;\n\tcurrWayPoint.wpAlt = 31000 ;\n\tcurrWayPoint.wpSpd = 200 ;" )
                    else:
                        wpElems = traceElems[currPosInTrace + 3].split(" ")
                        promelaCode.append("\tcurrWayPoint.wpName = " + wpElems[0]  + " ;")
                        promelaCode.append("\tcurrWayPoint.wpLat = " + str(int((float(wpElems[1][4:]) * 100) - 3393)) + " ;")
                        promelaCode.append("\tcurrWayPoint.wpLon = " + str(int((float(wpElems[2][4:]) * 100) + 11837)) + " ;")
                        #promelaCode.append("\tcurrWayPoint.wpAlt = " + str(int((float(wpElems[3][4:]) / 30850 ) * 256)) + " ;")
                        promelaCode.append("\tcurrWayPoint.wpAlt = " + str(int((float(wpElems[3][4:])  ) )) + " ;")
                        promelaCode.append("\tcurrWayPoint.wpSpd = " + str(int((float(wpElems[4][4:]) ) - 148)) + " ;")
    
                currPosInTrace = currPosInTrace + 4
                
            else:
                currPosInTrace = currPosInTrace + 4
        
        
    promelaCode.append(open('/Users/yasmeen/Research/TraceAnalysis/ending.pml',"r").read())
    
    
    print  "Promela creation complete. There are " + str(len(promelaCode)) + " lines in the promela file."
    
    if not(os.path.exists("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2])):
        os.mkdir("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2])
    open("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2] +'/CDactiontracefile.pml',"w").write("\n".join(promelaCode))
    print "Promela code written to disk."
    
    open("/Users/yasmeen/Research/TraceAnalysis/altitude.txt","w").write("\n".join(altitudeOutput))
    
    spinhandler.processPMLFile("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2] +'/CDactiontracefile.pml')
    os.chdir("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2])



def handleTraceWithSAL(traceFileName):
    '''
        Convert a csv simulation trace into SAL encoding
    '''
    
    traceContent = open( traceFileName,"r").read().split("\n")
    print "Trace file length " + str(len(traceContent))
    
    #desiredVariables = [ "CDAAC_altitude", 'CDAAC_groundspeed' , "CDAAC_latitude", "CDAAC_longitude" , "waypointtocompare", "altitude_clearance"]
    desiredVariables = [ "CDAAC_altitude", "waypointtocompare", "altitude_clearance"]
    variableDeclarations = { "CDAAC_altitude" : ['prevAlt','currAlt'], "waypointtocompare" : ['prevWayPoint','currWayPoint'], "altitude_clearance" : ["clearedAltitude"]} 
    translatedVariables = { 'CDAAC_altitude' : {'prevAlt' : '350', 
                                                  'currAlt': '350'}, 'waypointtocompare' : {'prevWayPoint.wpLat': '12', 
                                                                                                  'prevWayPoint.wpLon': '91', 
                                                                                                  'prevWayPoint.wpSpd': '100', 
                                                                                                  'prevWayPoint.wpAlt': '12100', 
                                                                                                  'prevWayPoint.wpName': 'RIIVR', 
                                                                                                  'currWayPoint.wpLat': '12', 
                                                                                                  'currWayPoint.wpLon': '91', 
                                                                                                  'currWayPoint.wpSpd': '100', 
                                                                                                  'currWayPoint.wpAlt': '12100', 
                                                                                                  'currWayPoint.wpName': 'RIIVR'}, 
                           'altitude_clearance' : {'clearedAltitude': '350'}}
    
        
    variableOwners = { "CDAAC_altitude" : "CDAAC", "waypointtocompare" : 'pilot', "altitude_clearance" : "ATC"}   
    variableTypes = { "CDAAC_altitude" : "altRange", "waypointtocompare" : 'waypointType', "altitude_clearance" : "altRange"}    
    altitudeOutput = []
    
    salModulesWithCode = {'automation' : [], 'ATC' : [] , 'CDAAC' : [] , 'pilot' : [] }
    salModuleOutputVariables = {'automation' : [], 'ATC' : [] , 'CDAAC' : [] , 'pilot' : [] }
       
    
    currTime = ""
    currTimeValue = 0 
    
    for salModule in salModulesWithCode:
        salModulesWithCode[salModule].append('%s: MODULE =\n \tBEGIN\n\t\tINPUT pc: stage'% (salModule))
    
    otherTransitionOfModule = { 'CDAAC' : False , 'ATC' : False , 'automation' : False , 'pilot': False}
    
    
    
    for outVar in desiredVariables:
        for varToBeDeclared in variableDeclarations[outVar]:
            if otherTransitionOfModule[variableOwners[outVar]]:
                #salModulesWithCode[variableOwners[outVar]][-1] = "%s ;" % salModulesWithCode[variableOwners[outVar]][-1]
                salModulesWithCode[variableOwners[outVar]].append("\n\t\tOUTPUT %s : %s" % ( varToBeDeclared, variableTypes[outVar]))
            else:
                salModulesWithCode[variableOwners[outVar]].append("\n\t\tOUTPUT %s : %s" % ( varToBeDeclared, variableTypes[outVar]))
                otherTransitionOfModule[variableOwners[outVar]] = True
    
    print ";".join(["\n\t\tOUTPUT %s : %s" % ( outVar, variableTypes[outVar]) for outVar in desiredVariables])
    
    for salModule in salModulesWithCode:
        salModulesWithCode[salModule].append('\n\tINITIALIZATION')   
    
        
    for outVar in desiredVariables:
        for varsToBeInitialized in translatedVariables[outVar].keys():   
            salModulesWithCode[variableOwners[outVar]].append("\n\t\t%s = %s ;" % ( varsToBeInitialized, translatedVariables[outVar][varsToBeInitialized]))
            """
            if varsToBeInitialized.find(".") > -1 :
                temp = "%s'.%s" % (varsToBeInitialized.split(".")[0] , ".".join(varsToBeInitialized.split(".")[1:]))
                salModulesWithCode[variableOwners[outVar]].append("\n\t\t%s = %s ;" % ( temp, translatedVariables[outVar][varsToBeInitialized]))
            else:         
                salModulesWithCode[variableOwners[outVar]].append("\n\t\t%s' = %s ;" % ( varsToBeInitialized, translatedVariables[outVar][varsToBeInitialized]))
    
            """
    for salModule in salModulesWithCode:    
        if salModulesWithCode[salModule][-1].endswith("INITIALIZATION"):
            salModulesWithCode[salModule][-1] = '\n\t\tTRANSITION\n\t\t\t['
        else:
            salModulesWithCode[salModule].append('\n\t\tTRANSITION\n\t\t\t[') 
    
    
    
    
    #open("/Users/yasmeen/Research/TraceAnalysis/juggle.txt", "w").write("\n".join(traceContent[50000:71000]))
    
    #firstPosInTrace = myFindIndex(traceContent, r"RIIVR LAT:34.028264 LON:-117.456531 ALT:12100 SPD:280")
    #lastPosInTrace = myFindIndex(traceContent, r"KRAIN LAT:34.005894 LON:-117.691711 ALT:9700 SPD:240", True)
    
    
    #print " from  " + str(firstPosInTrace) + " to " + str(lastPosInTrace)
    #print traceContent[firstPosInTrace]
    #for traceLine in traceContent[firstPosInTrace:lastPosInTrace]:
    for traceLine in traceContent[50000:68000]:
    #for traceLine in traceContent[50000:68000]:
    #for traceLine in traceContent[31000:43000]:
    #for traceLine in traceContent[48000:59000]:
    #for traceLine in traceContent[33000:42000]:
    #for traceLine in traceContent[33000:42000]:
    #for traceLine in traceContent[32000:41000]:
    #for traceLine in traceContent[34000:39000]:
    

    #for traceLine in traceContent[36000:41000]:
        
        traceElems = [traceElem.strip() for traceElem in traceLine.split("\t")]
    
        currModule = traceElems[2].split(" ")[1].strip()
    
        if traceElems[1].split(":")[1] == "dialVSSelector" :
            salModulesWithCode[currModule].append('manualAction\' = true ;')
        
        currPosInTrace = 4
        
 
    
        #if not (currTime == traceElems[0] ):
            #promelaCode.append("MockChan!true ;")
            #promelaCode.append("MockChan?true ;")
            #print "Here is a comment: %s empty" % (re.escape("% "))
            
            #salModulesWithCode[currModule].append("\% %s" % (str(traceElems[0])))
        """
        if not (currTime == '') and (otherTransitionOfModule[currModule] == True):
            salModulesWithCode[currModule].append("[]")
        else:
            otherTransitionOfModule[currModule] = True
        """
        
        if not (salModulesWithCode[currModule][-1].endswith("[")):
            salModulesWithCode[currModule].append("[]")
            
        currTime = traceElems[0]
        currTimeValue += 1
        if (currTimeValue == 4715):
            print "time:950"
        salModulesWithCode[currModule].append("pc = %s --> " % (str(currTimeValue)))

        while currPosInTrace < len(traceElems):
            if traceElems[currPosInTrace].startswith("NUT") :
                currPosInTrace = currPosInTrace + 5
            elif traceElems[currPosInTrace] == "Set resource" and ( traceElems[currPosInTrace+1] in desiredVariables) :
                if traceElems[currPosInTrace + 1 ] == "CDAAC_altitude" :
                    salModulesWithCode[currModule].append("\tprevAlt' = currAlt ;")
                    #promelaCode.append("\tcurrAlt = " + str(int((float(traceElems[currPosInTrace+3]) / 30850 ) * 256)) + " ;")
                    salModulesWithCode[currModule].append("\tcurrAlt' = " + str(int((float(traceElems[currPosInTrace+3])  ) )) + " ;")
                    altitudeOutput.append( traceElems[currPosInTrace+3])
                
                elif traceElems[currPosInTrace + 1 ] == "CDAAC_latitude" :
                    salModulesWithCode[currModule].append("\tprevLat' = currLat ;")
                    salModulesWithCode[currModule].append("\tcurrLat' = " + str(int((float(traceElems[currPosInTrace+3]) * 100) - 3393)) + " ;")
                
                elif traceElems[currPosInTrace + 1 ] == "CDAAC_longitude" :
                    salModulesWithCode[currModule].append("\tprevLon' = currLon ;")
                    salModulesWithCode[currModule].append("\tcurrLon' = " + str(int((float(traceElems[currPosInTrace+3]) * 100) + 11837)) + " ;")
    
                elif traceElems[currPosInTrace + 1 ] == "CDAAC_groundspeed" :
                    salModulesWithCode[currModule].append("\tprevSpd' = currSpd ;")
                    salModulesWithCode[currModule].append("\tcurrSpd' = " + str(int((float(traceElems[currPosInTrace+3]) ) - 148)) + " ;")
                
                elif traceElems[currPosInTrace + 1 ] == "altitude_clearance" :
                    salModulesWithCode[currModule].append("\tclearedAltitude' = " + str(int((float(traceElems[currPosInTrace+3]) ) )) + " ;")
    
                elif traceElems[currPosInTrace + 1 ] == "waypointtocompare" :
                    if salModulesWithCode[currModule][-1].endswith("["):
                        salModulesWithCode[currModule].append("pc = %s --> " % (str(currTimeValue)))
                    salModulesWithCode[currModule].append("\tprevWayPoint'.wpName = currWayPoint.wpName ;")
                    salModulesWithCode[currModule].append("\tprevWayPoint'.wpAlt = currWayPoint.wpAlt ;")
                    salModulesWithCode[currModule].append("\tprevWayPoint'.wpLat = currWayPoint.wpLat ;")
                    salModulesWithCode[currModule].append("\tprevWayPoint'.wpLon = currWayPoint.wpLon ;")
                    salModulesWithCode[currModule].append("\tprevWayPoint'.wpSpd = currWayPoint.wpSpd ;")
                    
                    if traceElems[currPosInTrace + 3].startswith("LAT"):                    
                        salModulesWithCode[currModule].append("\tcurrWayPoint'.wpName = START ;\n\tcurrWayPoint'.wpLat = 67 ;\n\tcurrWayPoint'.wpLon = 235 ;\n\tcurrWayPoint'.wpAlt = 31000 ;\n\tcurrWayPoint'.wpSpd = 200 ;" )
                    else:
                        wpElems = traceElems[currPosInTrace + 3].split(" ")
                        salModulesWithCode[currModule].append("\tcurrWayPoint'.wpName = " + wpElems[0]  + " ;")
                        salModulesWithCode[currModule].append("\tcurrWayPoint'.wpLat = " + str(int((float(wpElems[1][4:]) * 100) - 3393)) + " ;")
                        salModulesWithCode[currModule].append("\tcurrWayPoint'.wpLon = " + str(int((float(wpElems[2][4:]) * 100) + 11837)) + " ;")
                        #salModulesWithCode[currModule].append("\tcurrWayPoint.wpAlt = " + str(int((float(wpElems[3][4:]) / 30850 ) * 256)) + " ;")
                        salModulesWithCode[currModule].append("\tcurrWayPoint'.wpAlt = " + str(int((float(wpElems[3][4:])  ) )) + " ;")
                        salModulesWithCode[currModule].append("\tcurrWayPoint'.wpSpd = " + str(int((float(wpElems[4][4:]) ) - 148)) + " ;")
    
                currPosInTrace = currPosInTrace + 4
                
            else:
                currPosInTrace = currPosInTrace + 4
            
        if salModulesWithCode[currModule]:
            #print salModulesWithCode[currModule][-1]
            if salModulesWithCode[currModule][-1].startswith("pc"):
                salModulesWithCode[currModule].pop()
            if salModulesWithCode[currModule]:
                if salModulesWithCode[currModule][-1].startswith("[]"):
                    salModulesWithCode[currModule].pop()
            
        
    #salModulesWithCode[currModule].append(open('/Users/yasmeen/Research/TraceAnalysis/ending.sal',"r").read())
    
    print salModulesWithCode['automation']
    for salModule in salModulesWithCode.keys():
        if salModulesWithCode[salModule][-1].endswith('['):
            salModulesWithCode[salModule].append('\t\tELSE -->\n]\tEND;')
        else:
            salModulesWithCode[salModule].append('\t[]\n\t\tELSE -->\n]\tEND;')
    
    chain = itertools.chain.from_iterable([open('/Users/yasmeen/Research/TraceAnalysis/preamble.sal',"r").read().split("\n"),
                                           [ salCodeLine for salModule in salModulesWithCode.keys() for salCodeLine in salModulesWithCode[salModule]],
                                          open('/Users/yasmeen/Research/TraceAnalysis/ending.sal',"r").read().split("\n")])
    
 
    #print  "Promela creation complete. There are " + str(len(salModulesWithCode[currModule])) + " lines in the promela file."
    
    if not(os.path.exists("/Users/yasmeen/svnNASA/NASA 2009/WMC/WMCAnalysisWithSAL/"+ traceFileName.split("/")[-2])):
        os.mkdir("/Users/yasmeen/svnNASA/NASA 2009/WMC/WMCAnalysisWithSAL/"+ traceFileName.split("/")[-2])
    open("/Users/yasmeen/svnNASA/NASA 2009/WMC/WMCAnalysisWithSAL/"+ traceFileName.split("/")[-2] +'/CDA.sal',"w").write("\n".join(list(chain)))
    print "SAL code written to disk."
    
    #open("/Users/yasmeen/Research/TraceAnalysis/altitude.txt","w").write("\n".join(altitudeOutput))
    
    #spinhandler.processPMLFile("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2] +'/CDactiontracefile.pml')
    #os.chdir("/Users/yasmeen/svn/AY/FDRfiles/AIDCspin/"+ traceFileName.split("/")[-2])



def main():
    '''
        Usage:
        -m [ Spin / SAL] spin will be selected by default
        -f filename  
        -h help
    '''
    modelcheckerchosen = 'SPIN'
    filename = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:],'m:f:h', ['help'])
    except getopt.error, msg:
        print msg
        print 'for help use --help'
        sys.exit(2)
    
    for option, argvalue in opts :
        if option in ('-h', '--help'):
            print __doc__
        elif option == '-m':
            if argvalue.upper() == 'SPIN':
                modelcheckerchosen = 'SPIN'
            else:
                modelcheckerchosen = 'SAL'
        elif option == '-f' :
            filename = argvalue
    
    if filename == '' :
        print 'No filename specified!'
        return
    
    if modelcheckerchosen == 'SPIN':
        handleTraceWithSpin(filename)
    else:
        handleTraceWithSAL(filename)
    
    
if __name__ == "__main__" :
    main()
    