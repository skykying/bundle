'''
Created on Nov 28, 2012

@author: yasmeen
'''

import distutils.core

distutils.core.setup(name="SimulationTraceAnalyzer",
      version='0.1',
      author='Ayesha Yasmeen',
      authoremail='yasmeen@illinois.edu',
      py_modules=['spinhandler','traceConverter'],)